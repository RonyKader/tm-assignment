<?php

function shortcode_slider(){
	return 'MUNNA KHAN';
}
add_shortcode('slider','shortcode_slider');